"use client";

function ViewPaymentInfo() {
  return (
    <div className="m-4">
      <p className="font-semibold">
        You don't have any saved payment information
      </p>
    </div>
  );
}

export default ViewPaymentInfo;
