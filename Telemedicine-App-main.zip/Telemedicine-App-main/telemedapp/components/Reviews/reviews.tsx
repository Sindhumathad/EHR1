import React from "react";

const Reviews = () => {
  return <div></div>;
};
export default Reviews;
