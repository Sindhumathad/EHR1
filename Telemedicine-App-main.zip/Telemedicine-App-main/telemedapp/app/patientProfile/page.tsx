import ViewProfile from "@/components/patientProfile/ViewProfile";

function ViewProfilePage() {
  return <ViewProfile />;
}

export default ViewProfilePage;
