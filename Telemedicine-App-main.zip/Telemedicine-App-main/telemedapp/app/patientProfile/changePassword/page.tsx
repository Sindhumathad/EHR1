import ChangePassword from "@/components/patientProfile/ChangePassword";

function ChangePasswordPage() {
  return <ChangePassword />;
}

export default ChangePasswordPage;
