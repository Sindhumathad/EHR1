import TimeSlots from "@/components/doctorProfile/TimeSlots";

function TimeSlotsPage() {
  return <TimeSlots />;
}

export default TimeSlotsPage;
